import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:permission_handler/permission_handler.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  late final WebViewController _controller;
  int _selectedIndex = 0;
  bool _isLoading = true;
  double _progress = 0;

  final String _baseUrl = 'http://10.10.10.10:8096/web/index.html#!/startup/login.html?serverId=0b98b109688e42928fbfc49b67490fe6';

  @override
  void initState() {
    super.initState();
    _initController();
  }

  void _initController() {
    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(Colors.black)
      ..setNavigationDelegate(
        NavigationDelegate(
          onProgress: (int progress) {
            setState(() {
              _progress = progress / 100;
            });
          },
          onPageStarted: (String url) {
            setState(() {
              _isLoading = true;
            });
          },
          onPageFinished: (String url) {
            setState(() {
              _isLoading = false;
            });
          },
          onNavigationRequest: (NavigationRequest request) {
            // التعامل مع روابط التنزيل أو الروابط الخارجية
            if (request.url.contains('.mp4') || request.url.contains('.mkv') || request.url.contains('download')) {
              _handleDownload(request.url);
              return NavigationDecision.prevent;
            }
            return NavigationDecision.navigate;
          },
        ),
      )
      ..loadRequest(Uri.parse(_baseUrl));
  }

  Future<void> _handleDownload(String url) async {
    final status = await Permission.storage.request();
    if (status.isGranted) {
      // هنا يتم توجيه الرابط لمتصفح خارجي أو مدير تحميل لبدء التنزيل
      if (await canLaunchUrl(Uri.parse(url))) {
        await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('بدء التنزيل في المتصفح الخارجي...')),
        );
      }
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('يرجى إعطاء صلاحية التخزين للتحميل')),
      );
    }
  }

  Future<void> _launchWhatsApp() async {
    const whatsappUrl = "https://wa.me/967774449209"; // الرقم من الصورة
    if (await canLaunchUrl(Uri.parse(whatsappUrl))) {
      await launchUrl(Uri.parse(whatsappUrl), mode: LaunchMode.externalApplication);
    }
  }

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
    
    switch (index) {
      case 0:
        _controller.loadRequest(Uri.parse(_baseUrl));
        break;
      case 1:
        // يمكن إضافة صفحة بحث مخصصة أو الانتقال لقسم البحث في Emby
        _controller.loadRequest(Uri.parse('http://10.10.10.10:8096/web/index.html#!/search.html'));
        break;
      case 2:
        _launchWhatsApp();
        break;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: _selectedIndex == 0 ? PreferredSize(
        preferredSize: const Size.fromHeight(2),
        child: _isLoading 
          ? LinearProgressIndicator(value: _progress, color: const Color(0xFFD4AF37), backgroundColor: Colors.black)
          : const SizedBox.shrink(),
      ) : null,
      body: SafeArea(
        child: IndexedStack(
          index: _selectedIndex == 2 ? 0 : _selectedIndex, // للتبسيط، الواتساب يفتح خارجي ونبقى في الصفحة
          children: [
            WebViewWidget(controller: _controller),
            const Center(child: Text('صفحة البحث')), // سيتم تحميلها في الـ WebView عند الضغط
          ],
        ),
      ),
      bottomNavigationBar: Container(
        decoration: BoxDecoration(
          border: Border(top: BorderSide(color: Colors.white.withOpacity(0.1), width: 0.5)),
        ),
        child: BottomNavigationBar(
          backgroundColor: Colors.black,
          selectedItemColor: const Color(0xFFD4AF37),
          unselectedItemColor: Colors.grey,
          currentIndex: _selectedIndex,
          onTap: _onItemTapped,
          items: const [
            BottomNavigationBarItem(icon: Icon(Icons.home_filled), label: 'الرئيسية'),
            BottomNavigationBarItem(icon: Icon(Icons.search), label: 'بحث'),
            BottomNavigationBarItem(icon: Icon(Icons.chat), label: 'تواصل معنا'),
          ],
        ),
      ),
    );
  }
}
