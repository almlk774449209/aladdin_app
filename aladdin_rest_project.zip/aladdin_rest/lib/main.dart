import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'splash_screen.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  // إخفاء شريط الحالة لتجربة سينمائية
  SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
  runApp(const AladdinRestApp());
}

class AladdinRestApp extends StatelessWidget {
  const AladdinRestApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'استراحة علاء الدين',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        primaryColor: const Color(0xFFD4AF37), // لون ذهبي متناسق مع الشعار
        scaffoldBackgroundColor: Colors.black,
        useMaterial3: true,
      ),
      home: const SplashScreen(),
    );
  }
}
